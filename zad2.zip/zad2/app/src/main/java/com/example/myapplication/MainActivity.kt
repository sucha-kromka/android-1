package com.example.myapplication

import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import kotlin.random.Random

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val imageView = findViewById<ImageView>(R.id.imageView)
        val button = findViewById<Button>(R.id.button)
        val textView = findViewById<TextView>(R.id.textView)

        button.setOnClickListener {
            imageView.animate().apply {
                duration = 300
                rotationXBy(180f)
            }.withEndAction {

                val result = Random.nextBoolean()

                if (result) {
                    imageView.setImageResource(R.drawable.orzel)
                    textView.text =
                        "wylosowales orla symbol polskiej dumy narodu,siły, władzy i niezależności"
                } else {
                    imageView.setImageResource(R.drawable.reszka)
                    textView.text = "..wylosowales reszke, good job ig"
                }
            }.start()
        }
    }
}
