package com.example.zadanie1

import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.zadanie1.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.buttonShowData.setOnClickListener {
            val name = binding.editText.text.toString()

            if (name.isNotEmpty()) {
                Log.d("DaneApp", "wpisane dane: $name")

                binding.textViewResult.text = "podane imie i nazwisko: $name"

                Toast.makeText(this, "podane imie i nazwisko pliska: $name", Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(this, "daj imie i nazwisko pliska", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
